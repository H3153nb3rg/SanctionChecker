/*
 * Copyright (c) 2009, Giuseppe Cardone <ippatsuman@gmail.com>
 * All rights reserved.
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *  * Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *  * Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *  * Neither the name of the author nor the names of the contributors may be
 *    used to endorse or promote products derived from this software without
 *    specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY GIUSEPPE CARDONE ''AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL GIUSEPPE CARDONE BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */
package gcardone.junidecode;

/**
 * Character map for Unicode characters with codepoint U+83xx.
 * @author Giuseppe Cardone
 * @version 0.1
 */
class X83 {

    public static final String[] map = new String[]{
        "Fu ", // 0x00
        "Zhuo ", // 0x01
        "Mao ", // 0x02
        "Fan ", // 0x03
        "Qie ", // 0x04
        "Mao ", // 0x05
        "Mao ", // 0x06
        "Ba ", // 0x07
        "Zi ", // 0x08
        "Mo ", // 0x09
        "Zi ", // 0x0a
        "Di ", // 0x0b
        "Chi ", // 0x0c
        "Ji ", // 0x0d
        "Jing ", // 0x0e
        "Long ", // 0x0f
        "[?] ", // 0x10
        "Niao ", // 0x11
        "[?] ", // 0x12
        "Xue ", // 0x13
        "Ying ", // 0x14
        "Qiong ", // 0x15
        "Ge ", // 0x16
        "Ming ", // 0x17
        "Li ", // 0x18
        "Rong ", // 0x19
        "Yin ", // 0x1a
        "Gen ", // 0x1b
        "Qian ", // 0x1c
        "Chai ", // 0x1d
        "Chen ", // 0x1e
        "Yu ", // 0x1f
        "Xiu ", // 0x20
        "Zi ", // 0x21
        "Lie ", // 0x22
        "Wu ", // 0x23
        "Ji ", // 0x24
        "Kui ", // 0x25
        "Ce ", // 0x26
        "Chong ", // 0x27
        "Ci ", // 0x28
        "Gou ", // 0x29
        "Guang ", // 0x2a
        "Mang ", // 0x2b
        "Chi ", // 0x2c
        "Jiao ", // 0x2d
        "Jiao ", // 0x2e
        "Fu ", // 0x2f
        "Yu ", // 0x30
        "Zhu ", // 0x31
        "Zi ", // 0x32
        "Jiang ", // 0x33
        "Hui ", // 0x34
        "Yin ", // 0x35
        "Cha ", // 0x36
        "Fa ", // 0x37
        "Rong ", // 0x38
        "Ru ", // 0x39
        "Chong ", // 0x3a
        "Mang ", // 0x3b
        "Tong ", // 0x3c
        "Zhong ", // 0x3d
        "[?] ", // 0x3e
        "Zhu ", // 0x3f
        "Xun ", // 0x40
        "Huan ", // 0x41
        "Kua ", // 0x42
        "Quan ", // 0x43
        "Gai ", // 0x44
        "Da ", // 0x45
        "Jing ", // 0x46
        "Xing ", // 0x47
        "Quan ", // 0x48
        "Cao ", // 0x49
        "Jing ", // 0x4a
        "Er ", // 0x4b
        "An ", // 0x4c
        "Shou ", // 0x4d
        "Chi ", // 0x4e
        "Ren ", // 0x4f
        "Jian ", // 0x50
        "Ti ", // 0x51
        "Huang ", // 0x52
        "Ping ", // 0x53
        "Li ", // 0x54
        "Jin ", // 0x55
        "Lao ", // 0x56
        "Shu ", // 0x57
        "Zhuang ", // 0x58
        "Da ", // 0x59
        "Jia ", // 0x5a
        "Rao ", // 0x5b
        "Bi ", // 0x5c
        "Ze ", // 0x5d
        "Qiao ", // 0x5e
        "Hui ", // 0x5f
        "Qi ", // 0x60
        "Dang ", // 0x61
        "[?] ", // 0x62
        "Rong ", // 0x63
        "Hun ", // 0x64
        "Ying ", // 0x65
        "Luo ", // 0x66
        "Ying ", // 0x67
        "Xun ", // 0x68
        "Jin ", // 0x69
        "Sun ", // 0x6a
        "Yin ", // 0x6b
        "Mai ", // 0x6c
        "Hong ", // 0x6d
        "Zhou ", // 0x6e
        "Yao ", // 0x6f
        "Du ", // 0x70
        "Wei ", // 0x71
        "Chu ", // 0x72
        "Dou ", // 0x73
        "Fu ", // 0x74
        "Ren ", // 0x75
        "Yin ", // 0x76
        "He ", // 0x77
        "Bi ", // 0x78
        "Bu ", // 0x79
        "Yun ", // 0x7a
        "Di ", // 0x7b
        "Tu ", // 0x7c
        "Sui ", // 0x7d
        "Sui ", // 0x7e
        "Cheng ", // 0x7f
        "Chen ", // 0x80
        "Wu ", // 0x81
        "Bie ", // 0x82
        "Xi ", // 0x83
        "Geng ", // 0x84
        "Li ", // 0x85
        "Fu ", // 0x86
        "Zhu ", // 0x87
        "Mo ", // 0x88
        "Li ", // 0x89
        "Zhuang ", // 0x8a
        "Ji ", // 0x8b
        "Duo ", // 0x8c
        "Qiu ", // 0x8d
        "Sha ", // 0x8e
        "Suo ", // 0x8f
        "Chen ", // 0x90
        "Feng ", // 0x91
        "Ju ", // 0x92
        "Mei ", // 0x93
        "Meng ", // 0x94
        "Xing ", // 0x95
        "Jing ", // 0x96
        "Che ", // 0x97
        "Xin ", // 0x98
        "Jun ", // 0x99
        "Yan ", // 0x9a
        "Ting ", // 0x9b
        "Diao ", // 0x9c
        "Cuo ", // 0x9d
        "Wan ", // 0x9e
        "Han ", // 0x9f
        "You ", // 0xa0
        "Cuo ", // 0xa1
        "Jia ", // 0xa2
        "Wang ", // 0xa3
        "You ", // 0xa4
        "Niu ", // 0xa5
        "Shao ", // 0xa6
        "Xian ", // 0xa7
        "Lang ", // 0xa8
        "Fu ", // 0xa9
        "E ", // 0xaa
        "Mo ", // 0xab
        "Wen ", // 0xac
        "Jie ", // 0xad
        "Nan ", // 0xae
        "Mu ", // 0xaf
        "Kan ", // 0xb0
        "Lai ", // 0xb1
        "Lian ", // 0xb2
        "Shi ", // 0xb3
        "Wo ", // 0xb4
        "Usagi ", // 0xb5
        "Lian ", // 0xb6
        "Huo ", // 0xb7
        "You ", // 0xb8
        "Ying ", // 0xb9
        "Ying ", // 0xba
        "Nuc ", // 0xbb
        "Chun ", // 0xbc
        "Mang ", // 0xbd
        "Mang ", // 0xbe
        "Ci ", // 0xbf
        "Wan ", // 0xc0
        "Jing ", // 0xc1
        "Di ", // 0xc2
        "Qu ", // 0xc3
        "Dong ", // 0xc4
        "Jian ", // 0xc5
        "Zou ", // 0xc6
        "Gu ", // 0xc7
        "La ", // 0xc8
        "Lu ", // 0xc9
        "Ju ", // 0xca
        "Wei ", // 0xcb
        "Jun ", // 0xcc
        "Nie ", // 0xcd
        "Kun ", // 0xce
        "He ", // 0xcf
        "Pu ", // 0xd0
        "Zi ", // 0xd1
        "Gao ", // 0xd2
        "Guo ", // 0xd3
        "Fu ", // 0xd4
        "Lun ", // 0xd5
        "Chang ", // 0xd6
        "Chou ", // 0xd7
        "Song ", // 0xd8
        "Chui ", // 0xd9
        "Zhan ", // 0xda
        "Men ", // 0xdb
        "Cai ", // 0xdc
        "Ba ", // 0xdd
        "Li ", // 0xde
        "Tu ", // 0xdf
        "Bo ", // 0xe0
        "Han ", // 0xe1
        "Bao ", // 0xe2
        "Qin ", // 0xe3
        "Juan ", // 0xe4
        "Xi ", // 0xe5
        "Qin ", // 0xe6
        "Di ", // 0xe7
        "Jie ", // 0xe8
        "Pu ", // 0xe9
        "Dang ", // 0xea
        "Jin ", // 0xeb
        "Zhao ", // 0xec
        "Tai ", // 0xed
        "Geng ", // 0xee
        "Hua ", // 0xef
        "Gu ", // 0xf0
        "Ling ", // 0xf1
        "Fei ", // 0xf2
        "Jin ", // 0xf3
        "An ", // 0xf4
        "Wang ", // 0xf5
        "Beng ", // 0xf6
        "Zhou ", // 0xf7
        "Yan ", // 0xf8
        "Ju ", // 0xf9
        "Jian ", // 0xfa
        "Lin ", // 0xfb
        "Tan ", // 0xfc
        "Shu ", // 0xfd
        "Tian ", // 0xfe
        "Dao " // 0xff
    };
}
