/*
 * Copyright (c) 2009, Giuseppe Cardone <ippatsuman@gmail.com>
 * All rights reserved.
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *  * Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *  * Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *  * Neither the name of the author nor the names of the contributors may be
 *    used to endorse or promote products derived from this software without
 *    specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY GIUSEPPE CARDONE ''AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL GIUSEPPE CARDONE BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */
package gcardone.junidecode;

/**
 * Character map for Unicode characters with codepoint U+91xx.
 * @author Giuseppe Cardone
 * @version 0.1
 */
class X91 {

    public static final String[] map = new String[]{
        "Ruo ", // 0x00
        "Bei ", // 0x01
        "E ", // 0x02
        "Yu ", // 0x03
        "Juan ", // 0x04
        "Yu ", // 0x05
        "Yun ", // 0x06
        "Hou ", // 0x07
        "Kui ", // 0x08
        "Xiang ", // 0x09
        "Xiang ", // 0x0a
        "Sou ", // 0x0b
        "Tang ", // 0x0c
        "Ming ", // 0x0d
        "Xi ", // 0x0e
        "Ru ", // 0x0f
        "Chu ", // 0x10
        "Zi ", // 0x11
        "Zou ", // 0x12
        "Ju ", // 0x13
        "Wu ", // 0x14
        "Xiang ", // 0x15
        "Yun ", // 0x16
        "Hao ", // 0x17
        "Yong ", // 0x18
        "Bi ", // 0x19
        "Mo ", // 0x1a
        "Chao ", // 0x1b
        "Fu ", // 0x1c
        "Liao ", // 0x1d
        "Yin ", // 0x1e
        "Zhuan ", // 0x1f
        "Hu ", // 0x20
        "Qiao ", // 0x21
        "Yan ", // 0x22
        "Zhang ", // 0x23
        "Fan ", // 0x24
        "Qiao ", // 0x25
        "Xu ", // 0x26
        "Deng ", // 0x27
        "Bi ", // 0x28
        "Xin ", // 0x29
        "Bi ", // 0x2a
        "Ceng ", // 0x2b
        "Wei ", // 0x2c
        "Zheng ", // 0x2d
        "Mao ", // 0x2e
        "Shan ", // 0x2f
        "Lin ", // 0x30
        "Po ", // 0x31
        "Dan ", // 0x32
        "Meng ", // 0x33
        "Ye ", // 0x34
        "Cao ", // 0x35
        "Kuai ", // 0x36
        "Feng ", // 0x37
        "Meng ", // 0x38
        "Zou ", // 0x39
        "Kuang ", // 0x3a
        "Lian ", // 0x3b
        "Zan ", // 0x3c
        "Chan ", // 0x3d
        "You ", // 0x3e
        "Qi ", // 0x3f
        "Yan ", // 0x40
        "Chan ", // 0x41
        "Zan ", // 0x42
        "Ling ", // 0x43
        "Huan ", // 0x44
        "Xi ", // 0x45
        "Feng ", // 0x46
        "Zan ", // 0x47
        "Li ", // 0x48
        "You ", // 0x49
        "Ding ", // 0x4a
        "Qiu ", // 0x4b
        "Zhuo ", // 0x4c
        "Pei ", // 0x4d
        "Zhou ", // 0x4e
        "Yi ", // 0x4f
        "Hang ", // 0x50
        "Yu ", // 0x51
        "Jiu ", // 0x52
        "Yan ", // 0x53
        "Zui ", // 0x54
        "Mao ", // 0x55
        "Dan ", // 0x56
        "Xu ", // 0x57
        "Tou ", // 0x58
        "Zhen ", // 0x59
        "Fen ", // 0x5a
        "Sakenomoto ", // 0x5b
        "[?] ", // 0x5c
        "Yun ", // 0x5d
        "Tai ", // 0x5e
        "Tian ", // 0x5f
        "Qia ", // 0x60
        "Tuo ", // 0x61
        "Zuo ", // 0x62
        "Han ", // 0x63
        "Gu ", // 0x64
        "Su ", // 0x65
        "Po ", // 0x66
        "Chou ", // 0x67
        "Zai ", // 0x68
        "Ming ", // 0x69
        "Luo ", // 0x6a
        "Chuo ", // 0x6b
        "Chou ", // 0x6c
        "You ", // 0x6d
        "Tong ", // 0x6e
        "Zhi ", // 0x6f
        "Xian ", // 0x70
        "Jiang ", // 0x71
        "Cheng ", // 0x72
        "Yin ", // 0x73
        "Tu ", // 0x74
        "Xiao ", // 0x75
        "Mei ", // 0x76
        "Ku ", // 0x77
        "Suan ", // 0x78
        "Lei ", // 0x79
        "Pu ", // 0x7a
        "Zui ", // 0x7b
        "Hai ", // 0x7c
        "Yan ", // 0x7d
        "Xi ", // 0x7e
        "Niang ", // 0x7f
        "Wei ", // 0x80
        "Lu ", // 0x81
        "Lan ", // 0x82
        "Yan ", // 0x83
        "Tao ", // 0x84
        "Pei ", // 0x85
        "Zhan ", // 0x86
        "Chun ", // 0x87
        "Tan ", // 0x88
        "Zui ", // 0x89
        "Chuo ", // 0x8a
        "Cu ", // 0x8b
        "Kun ", // 0x8c
        "Ti ", // 0x8d
        "Mian ", // 0x8e
        "Du ", // 0x8f
        "Hu ", // 0x90
        "Xu ", // 0x91
        "Xing ", // 0x92
        "Tan ", // 0x93
        "Jiu ", // 0x94
        "Chun ", // 0x95
        "Yun ", // 0x96
        "Po ", // 0x97
        "Ke ", // 0x98
        "Sou ", // 0x99
        "Mi ", // 0x9a
        "Quan ", // 0x9b
        "Chou ", // 0x9c
        "Cuo ", // 0x9d
        "Yun ", // 0x9e
        "Yong ", // 0x9f
        "Ang ", // 0xa0
        "Zha ", // 0xa1
        "Hai ", // 0xa2
        "Tang ", // 0xa3
        "Jiang ", // 0xa4
        "Piao ", // 0xa5
        "Shan ", // 0xa6
        "Yu ", // 0xa7
        "Li ", // 0xa8
        "Zao ", // 0xa9
        "Lao ", // 0xaa
        "Yi ", // 0xab
        "Jiang ", // 0xac
        "Pu ", // 0xad
        "Jiao ", // 0xae
        "Xi ", // 0xaf
        "Tan ", // 0xb0
        "Po ", // 0xb1
        "Nong ", // 0xb2
        "Yi ", // 0xb3
        "Li ", // 0xb4
        "Ju ", // 0xb5
        "Jiao ", // 0xb6
        "Yi ", // 0xb7
        "Niang ", // 0xb8
        "Ru ", // 0xb9
        "Xun ", // 0xba
        "Chou ", // 0xbb
        "Yan ", // 0xbc
        "Ling ", // 0xbd
        "Mi ", // 0xbe
        "Mi ", // 0xbf
        "Niang ", // 0xc0
        "Xin ", // 0xc1
        "Jiao ", // 0xc2
        "Xi ", // 0xc3
        "Mi ", // 0xc4
        "Yan ", // 0xc5
        "Bian ", // 0xc6
        "Cai ", // 0xc7
        "Shi ", // 0xc8
        "You ", // 0xc9
        "Shi ", // 0xca
        "Shi ", // 0xcb
        "Li ", // 0xcc
        "Zhong ", // 0xcd
        "Ye ", // 0xce
        "Liang ", // 0xcf
        "Li ", // 0xd0
        "Jin ", // 0xd1
        "Jin ", // 0xd2
        "Qiu ", // 0xd3
        "Yi ", // 0xd4
        "Diao ", // 0xd5
        "Dao ", // 0xd6
        "Zhao ", // 0xd7
        "Ding ", // 0xd8
        "Po ", // 0xd9
        "Qiu ", // 0xda
        "He ", // 0xdb
        "Fu ", // 0xdc
        "Zhen ", // 0xdd
        "Zhi ", // 0xde
        "Ba ", // 0xdf
        "Luan ", // 0xe0
        "Fu ", // 0xe1
        "Nai ", // 0xe2
        "Diao ", // 0xe3
        "Shan ", // 0xe4
        "Qiao ", // 0xe5
        "Kou ", // 0xe6
        "Chuan ", // 0xe7
        "Zi ", // 0xe8
        "Fan ", // 0xe9
        "Yu ", // 0xea
        "Hua ", // 0xeb
        "Han ", // 0xec
        "Gong ", // 0xed
        "Qi ", // 0xee
        "Mang ", // 0xef
        "Ri ", // 0xf0
        "Di ", // 0xf1
        "Si ", // 0xf2
        "Xi ", // 0xf3
        "Yi ", // 0xf4
        "Chai ", // 0xf5
        "Shi ", // 0xf6
        "Tu ", // 0xf7
        "Xi ", // 0xf8
        "Nu ", // 0xf9
        "Qian ", // 0xfa
        "Ishiyumi ", // 0xfb
        "Jian ", // 0xfc
        "Pi ", // 0xfd
        "Ye ", // 0xfe
        "Yin " // 0xff
    };
}
