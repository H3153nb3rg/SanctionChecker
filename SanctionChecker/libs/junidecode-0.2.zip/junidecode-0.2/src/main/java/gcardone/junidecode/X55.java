/*
 * Copyright (c) 2009, Giuseppe Cardone <ippatsuman@gmail.com>
 * All rights reserved.
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *  * Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *  * Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *  * Neither the name of the author nor the names of the contributors may be
 *    used to endorse or promote products derived from this software without
 *    specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY GIUSEPPE CARDONE ''AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL GIUSEPPE CARDONE BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */
package gcardone.junidecode;

/**
 * Character map for Unicode characters with codepoint U+55xx.
 * @author Giuseppe Cardone
 * @version 0.1
 */
class X55 {

    public static final String[] map = new String[]{
        "You ", // 0x00
        "Yan ", // 0x01
        "Gu ", // 0x02
        "Gu ", // 0x03
        "Bai ", // 0x04
        "Han ", // 0x05
        "Suo ", // 0x06
        "Chun ", // 0x07
        "Yi ", // 0x08
        "Ai ", // 0x09
        "Jia ", // 0x0a
        "Tu ", // 0x0b
        "Xian ", // 0x0c
        "Huan ", // 0x0d
        "Li ", // 0x0e
        "Xi ", // 0x0f
        "Tang ", // 0x10
        "Zuo ", // 0x11
        "Qiu ", // 0x12
        "Che ", // 0x13
        "Wu ", // 0x14
        "Zao ", // 0x15
        "Ya ", // 0x16
        "Dou ", // 0x17
        "Qi ", // 0x18
        "Di ", // 0x19
        "Qin ", // 0x1a
        "Ma ", // 0x1b
        "Mal ", // 0x1c
        "Hong ", // 0x1d
        "Dou ", // 0x1e
        "Kes ", // 0x1f
        "Lao ", // 0x20
        "Liang ", // 0x21
        "Suo ", // 0x22
        "Zao ", // 0x23
        "Huan ", // 0x24
        "Lang ", // 0x25
        "Sha ", // 0x26
        "Ji ", // 0x27
        "Zuo ", // 0x28
        "Wo ", // 0x29
        "Feng ", // 0x2a
        "Yin ", // 0x2b
        "Hu ", // 0x2c
        "Qi ", // 0x2d
        "Shou ", // 0x2e
        "Wei ", // 0x2f
        "Shua ", // 0x30
        "Chang ", // 0x31
        "Er ", // 0x32
        "Li ", // 0x33
        "Qiang ", // 0x34
        "An ", // 0x35
        "Jie ", // 0x36
        "Yo ", // 0x37
        "Nian ", // 0x38
        "Yu ", // 0x39
        "Tian ", // 0x3a
        "Lai ", // 0x3b
        "Sha ", // 0x3c
        "Xi ", // 0x3d
        "Tuo ", // 0x3e
        "Hu ", // 0x3f
        "Ai ", // 0x40
        "Zhou ", // 0x41
        "Nou ", // 0x42
        "Ken ", // 0x43
        "Zhuo ", // 0x44
        "Zhuo ", // 0x45
        "Shang ", // 0x46
        "Di ", // 0x47
        "Heng ", // 0x48
        "Lan ", // 0x49
        "A ", // 0x4a
        "Xiao ", // 0x4b
        "Xiang ", // 0x4c
        "Tun ", // 0x4d
        "Wu ", // 0x4e
        "Wen ", // 0x4f
        "Cui ", // 0x50
        "Sha ", // 0x51
        "Hu ", // 0x52
        "Qi ", // 0x53
        "Qi ", // 0x54
        "Tao ", // 0x55
        "Dan ", // 0x56
        "Dan ", // 0x57
        "Ye ", // 0x58
        "Zi ", // 0x59
        "Bi ", // 0x5a
        "Cui ", // 0x5b
        "Chuo ", // 0x5c
        "He ", // 0x5d
        "Ya ", // 0x5e
        "Qi ", // 0x5f
        "Zhe ", // 0x60
        "Pei ", // 0x61
        "Liang ", // 0x62
        "Xian ", // 0x63
        "Pi ", // 0x64
        "Sha ", // 0x65
        "La ", // 0x66
        "Ze ", // 0x67
        "Qing ", // 0x68
        "Gua ", // 0x69
        "Pa ", // 0x6a
        "Zhe ", // 0x6b
        "Se ", // 0x6c
        "Zhuan ", // 0x6d
        "Nie ", // 0x6e
        "Guo ", // 0x6f
        "Luo ", // 0x70
        "Yan ", // 0x71
        "Di ", // 0x72
        "Quan ", // 0x73
        "Tan ", // 0x74
        "Bo ", // 0x75
        "Ding ", // 0x76
        "Lang ", // 0x77
        "Xiao ", // 0x78
        "[?] ", // 0x79
        "Tang ", // 0x7a
        "Chi ", // 0x7b
        "Ti ", // 0x7c
        "An ", // 0x7d
        "Jiu ", // 0x7e
        "Dan ", // 0x7f
        "Ke ", // 0x80
        "Yong ", // 0x81
        "Wei ", // 0x82
        "Nan ", // 0x83
        "Shan ", // 0x84
        "Yu ", // 0x85
        "Zhe ", // 0x86
        "La ", // 0x87
        "Jie ", // 0x88
        "Hou ", // 0x89
        "Han ", // 0x8a
        "Die ", // 0x8b
        "Zhou ", // 0x8c
        "Chai ", // 0x8d
        "Wai ", // 0x8e
        "Re ", // 0x8f
        "Yu ", // 0x90
        "Yin ", // 0x91
        "Zan ", // 0x92
        "Yao ", // 0x93
        "Wo ", // 0x94
        "Mian ", // 0x95
        "Hu ", // 0x96
        "Yun ", // 0x97
        "Chuan ", // 0x98
        "Hui ", // 0x99
        "Huan ", // 0x9a
        "Huan ", // 0x9b
        "Xi ", // 0x9c
        "He ", // 0x9d
        "Ji ", // 0x9e
        "Kui ", // 0x9f
        "Zhong ", // 0xa0
        "Wei ", // 0xa1
        "Sha ", // 0xa2
        "Xu ", // 0xa3
        "Huang ", // 0xa4
        "Du ", // 0xa5
        "Nie ", // 0xa6
        "Xuan ", // 0xa7
        "Liang ", // 0xa8
        "Yu ", // 0xa9
        "Sang ", // 0xaa
        "Chi ", // 0xab
        "Qiao ", // 0xac
        "Yan ", // 0xad
        "Dan ", // 0xae
        "Pen ", // 0xaf
        "Can ", // 0xb0
        "Li ", // 0xb1
        "Yo ", // 0xb2
        "Zha ", // 0xb3
        "Wei ", // 0xb4
        "Miao ", // 0xb5
        "Ying ", // 0xb6
        "Pen ", // 0xb7
        "Phos ", // 0xb8
        "Kui ", // 0xb9
        "Xi ", // 0xba
        "Yu ", // 0xbb
        "Jie ", // 0xbc
        "Lou ", // 0xbd
        "Ku ", // 0xbe
        "Sao ", // 0xbf
        "Huo ", // 0xc0
        "Ti ", // 0xc1
        "Yao ", // 0xc2
        "He ", // 0xc3
        "A ", // 0xc4
        "Xiu ", // 0xc5
        "Qiang ", // 0xc6
        "Se ", // 0xc7
        "Yong ", // 0xc8
        "Su ", // 0xc9
        "Hong ", // 0xca
        "Xie ", // 0xcb
        "Yi ", // 0xcc
        "Suo ", // 0xcd
        "Ma ", // 0xce
        "Cha ", // 0xcf
        "Hai ", // 0xd0
        "Ke ", // 0xd1
        "Ta ", // 0xd2
        "Sang ", // 0xd3
        "Tian ", // 0xd4
        "Ru ", // 0xd5
        "Sou ", // 0xd6
        "Wa ", // 0xd7
        "Ji ", // 0xd8
        "Pang ", // 0xd9
        "Wu ", // 0xda
        "Xian ", // 0xdb
        "Shi ", // 0xdc
        "Ge ", // 0xdd
        "Zi ", // 0xde
        "Jie ", // 0xdf
        "Luo ", // 0xe0
        "Weng ", // 0xe1
        "Wa ", // 0xe2
        "Si ", // 0xe3
        "Chi ", // 0xe4
        "Hao ", // 0xe5
        "Suo ", // 0xe6
        "Jia ", // 0xe7
        "Hai ", // 0xe8
        "Suo ", // 0xe9
        "Qin ", // 0xea
        "Nie ", // 0xeb
        "He ", // 0xec
        "Cis ", // 0xed
        "Sai ", // 0xee
        "Ng ", // 0xef
        "Ge ", // 0xf0
        "Na ", // 0xf1
        "Dia ", // 0xf2
        "Ai ", // 0xf3
        "[?] ", // 0xf4
        "Tong ", // 0xf5
        "Bi ", // 0xf6
        "Ao ", // 0xf7
        "Ao ", // 0xf8
        "Lian ", // 0xf9
        "Cui ", // 0xfa
        "Zhe ", // 0xfb
        "Mo ", // 0xfc
        "Sou ", // 0xfd
        "Sou ", // 0xfe
        "Tan " // 0xff
    };
}
