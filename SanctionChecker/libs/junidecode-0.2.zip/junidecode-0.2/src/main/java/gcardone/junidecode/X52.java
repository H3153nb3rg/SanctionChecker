/*
 * Copyright (c) 2009, Giuseppe Cardone <ippatsuman@gmail.com>
 * All rights reserved.
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *  * Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *  * Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *  * Neither the name of the author nor the names of the contributors may be
 *    used to endorse or promote products derived from this software without
 *    specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY GIUSEPPE CARDONE ''AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL GIUSEPPE CARDONE BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */
package gcardone.junidecode;

/**
 * Character map for Unicode characters with codepoint U+52xx.
 * @author Giuseppe Cardone
 * @version 0.1
 */
class X52 {

    public static final String[] map = new String[]{
        "Dao ", // 0x00
        "Diao ", // 0x01
        "Dao ", // 0x02
        "Ren ", // 0x03
        "Ren ", // 0x04
        "Chuang ", // 0x05
        "Fen ", // 0x06
        "Qie ", // 0x07
        "Yi ", // 0x08
        "Ji ", // 0x09
        "Kan ", // 0x0a
        "Qian ", // 0x0b
        "Cun ", // 0x0c
        "Chu ", // 0x0d
        "Wen ", // 0x0e
        "Ji ", // 0x0f
        "Dan ", // 0x10
        "Xing ", // 0x11
        "Hua ", // 0x12
        "Wan ", // 0x13
        "Jue ", // 0x14
        "Li ", // 0x15
        "Yue ", // 0x16
        "Lie ", // 0x17
        "Liu ", // 0x18
        "Ze ", // 0x19
        "Gang ", // 0x1a
        "Chuang ", // 0x1b
        "Fu ", // 0x1c
        "Chu ", // 0x1d
        "Qu ", // 0x1e
        "Ju ", // 0x1f
        "Shan ", // 0x20
        "Min ", // 0x21
        "Ling ", // 0x22
        "Zhong ", // 0x23
        "Pan ", // 0x24
        "Bie ", // 0x25
        "Jie ", // 0x26
        "Jie ", // 0x27
        "Bao ", // 0x28
        "Li ", // 0x29
        "Shan ", // 0x2a
        "Bie ", // 0x2b
        "Chan ", // 0x2c
        "Jing ", // 0x2d
        "Gua ", // 0x2e
        "Gen ", // 0x2f
        "Dao ", // 0x30
        "Chuang ", // 0x31
        "Kui ", // 0x32
        "Ku ", // 0x33
        "Duo ", // 0x34
        "Er ", // 0x35
        "Zhi ", // 0x36
        "Shua ", // 0x37
        "Quan ", // 0x38
        "Cha ", // 0x39
        "Ci ", // 0x3a
        "Ke ", // 0x3b
        "Jie ", // 0x3c
        "Gui ", // 0x3d
        "Ci ", // 0x3e
        "Gui ", // 0x3f
        "Kai ", // 0x40
        "Duo ", // 0x41
        "Ji ", // 0x42
        "Ti ", // 0x43
        "Jing ", // 0x44
        "Lou ", // 0x45
        "Gen ", // 0x46
        "Ze ", // 0x47
        "Yuan ", // 0x48
        "Cuo ", // 0x49
        "Xue ", // 0x4a
        "Ke ", // 0x4b
        "La ", // 0x4c
        "Qian ", // 0x4d
        "Cha ", // 0x4e
        "Chuang ", // 0x4f
        "Gua ", // 0x50
        "Jian ", // 0x51
        "Cuo ", // 0x52
        "Li ", // 0x53
        "Ti ", // 0x54
        "Fei ", // 0x55
        "Pou ", // 0x56
        "Chan ", // 0x57
        "Qi ", // 0x58
        "Chuang ", // 0x59
        "Zi ", // 0x5a
        "Gang ", // 0x5b
        "Wan ", // 0x5c
        "Bo ", // 0x5d
        "Ji ", // 0x5e
        "Duo ", // 0x5f
        "Qing ", // 0x60
        "Yan ", // 0x61
        "Zhuo ", // 0x62
        "Jian ", // 0x63
        "Ji ", // 0x64
        "Bo ", // 0x65
        "Yan ", // 0x66
        "Ju ", // 0x67
        "Huo ", // 0x68
        "Sheng ", // 0x69
        "Jian ", // 0x6a
        "Duo ", // 0x6b
        "Duan ", // 0x6c
        "Wu ", // 0x6d
        "Gua ", // 0x6e
        "Fu ", // 0x6f
        "Sheng ", // 0x70
        "Jian ", // 0x71
        "Ge ", // 0x72
        "Zha ", // 0x73
        "Kai ", // 0x74
        "Chuang ", // 0x75
        "Juan ", // 0x76
        "Chan ", // 0x77
        "Tuan ", // 0x78
        "Lu ", // 0x79
        "Li ", // 0x7a
        "Fou ", // 0x7b
        "Shan ", // 0x7c
        "Piao ", // 0x7d
        "Kou ", // 0x7e
        "Jiao ", // 0x7f
        "Gua ", // 0x80
        "Qiao ", // 0x81
        "Jue ", // 0x82
        "Hua ", // 0x83
        "Zha ", // 0x84
        "Zhuo ", // 0x85
        "Lian ", // 0x86
        "Ju ", // 0x87
        "Pi ", // 0x88
        "Liu ", // 0x89
        "Gui ", // 0x8a
        "Jiao ", // 0x8b
        "Gui ", // 0x8c
        "Jian ", // 0x8d
        "Jian ", // 0x8e
        "Tang ", // 0x8f
        "Huo ", // 0x90
        "Ji ", // 0x91
        "Jian ", // 0x92
        "Yi ", // 0x93
        "Jian ", // 0x94
        "Zhi ", // 0x95
        "Chan ", // 0x96
        "Cuan ", // 0x97
        "Mo ", // 0x98
        "Li ", // 0x99
        "Zhu ", // 0x9a
        "Li ", // 0x9b
        "Ya ", // 0x9c
        "Quan ", // 0x9d
        "Ban ", // 0x9e
        "Gong ", // 0x9f
        "Jia ", // 0xa0
        "Wu ", // 0xa1
        "Mai ", // 0xa2
        "Lie ", // 0xa3
        "Jin ", // 0xa4
        "Keng ", // 0xa5
        "Xie ", // 0xa6
        "Zhi ", // 0xa7
        "Dong ", // 0xa8
        "Zhu ", // 0xa9
        "Nu ", // 0xaa
        "Jie ", // 0xab
        "Qu ", // 0xac
        "Shao ", // 0xad
        "Yi ", // 0xae
        "Zhu ", // 0xaf
        "Miao ", // 0xb0
        "Li ", // 0xb1
        "Jing ", // 0xb2
        "Lao ", // 0xb3
        "Lao ", // 0xb4
        "Juan ", // 0xb5
        "Kou ", // 0xb6
        "Yang ", // 0xb7
        "Wa ", // 0xb8
        "Xiao ", // 0xb9
        "Mou ", // 0xba
        "Kuang ", // 0xbb
        "Jie ", // 0xbc
        "Lie ", // 0xbd
        "He ", // 0xbe
        "Shi ", // 0xbf
        "Ke ", // 0xc0
        "Jing ", // 0xc1
        "Hao ", // 0xc2
        "Bo ", // 0xc3
        "Min ", // 0xc4
        "Chi ", // 0xc5
        "Lang ", // 0xc6
        "Yong ", // 0xc7
        "Yong ", // 0xc8
        "Mian ", // 0xc9
        "Ke ", // 0xca
        "Xun ", // 0xcb
        "Juan ", // 0xcc
        "Qing ", // 0xcd
        "Lu ", // 0xce
        "Pou ", // 0xcf
        "Meng ", // 0xd0
        "Lai ", // 0xd1
        "Le ", // 0xd2
        "Kai ", // 0xd3
        "Mian ", // 0xd4
        "Dong ", // 0xd5
        "Xu ", // 0xd6
        "Xu ", // 0xd7
        "Kan ", // 0xd8
        "Wu ", // 0xd9
        "Yi ", // 0xda
        "Xun ", // 0xdb
        "Weng ", // 0xdc
        "Sheng ", // 0xdd
        "Lao ", // 0xde
        "Mu ", // 0xdf
        "Lu ", // 0xe0
        "Piao ", // 0xe1
        "Shi ", // 0xe2
        "Ji ", // 0xe3
        "Qin ", // 0xe4
        "Qiang ", // 0xe5
        "Jiao ", // 0xe6
        "Quan ", // 0xe7
        "Yang ", // 0xe8
        "Yi ", // 0xe9
        "Jue ", // 0xea
        "Fan ", // 0xeb
        "Juan ", // 0xec
        "Tong ", // 0xed
        "Ju ", // 0xee
        "Dan ", // 0xef
        "Xie ", // 0xf0
        "Mai ", // 0xf1
        "Xun ", // 0xf2
        "Xun ", // 0xf3
        "Lu ", // 0xf4
        "Li ", // 0xf5
        "Che ", // 0xf6
        "Rang ", // 0xf7
        "Quan ", // 0xf8
        "Bao ", // 0xf9
        "Shao ", // 0xfa
        "Yun ", // 0xfb
        "Jiu ", // 0xfc
        "Bao ", // 0xfd
        "Gou ", // 0xfe
        "Wu " // 0xff
    };
}
