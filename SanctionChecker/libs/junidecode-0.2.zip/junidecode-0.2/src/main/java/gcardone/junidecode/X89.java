/*
 * Copyright (c) 2009, Giuseppe Cardone <ippatsuman@gmail.com>
 * All rights reserved.
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *  * Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *  * Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *  * Neither the name of the author nor the names of the contributors may be
 *    used to endorse or promote products derived from this software without
 *    specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY GIUSEPPE CARDONE ''AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL GIUSEPPE CARDONE BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */
package gcardone.junidecode;

/**
 * Character map for Unicode characters with codepoint U+89xx.
 * @author Giuseppe Cardone
 * @version 0.1
 */
class X89 {

    public static final String[] map = new String[]{
        "Ji ", // 0x00
        "Zhi ", // 0x01
        "Gua ", // 0x02
        "Ken ", // 0x03
        "Che ", // 0x04
        "Ti ", // 0x05
        "Ti ", // 0x06
        "Fu ", // 0x07
        "Chong ", // 0x08
        "Xie ", // 0x09
        "Bian ", // 0x0a
        "Die ", // 0x0b
        "Kun ", // 0x0c
        "Duan ", // 0x0d
        "Xiu ", // 0x0e
        "Xiu ", // 0x0f
        "He ", // 0x10
        "Yuan ", // 0x11
        "Bao ", // 0x12
        "Bao ", // 0x13
        "Fu ", // 0x14
        "Yu ", // 0x15
        "Tuan ", // 0x16
        "Yan ", // 0x17
        "Hui ", // 0x18
        "Bei ", // 0x19
        "Chu ", // 0x1a
        "Lu ", // 0x1b
        "Ena ", // 0x1c
        "Hitoe ", // 0x1d
        "Yun ", // 0x1e
        "Da ", // 0x1f
        "Gou ", // 0x20
        "Da ", // 0x21
        "Huai ", // 0x22
        "Rong ", // 0x23
        "Yuan ", // 0x24
        "Ru ", // 0x25
        "Nai ", // 0x26
        "Jiong ", // 0x27
        "Suo ", // 0x28
        "Ban ", // 0x29
        "Tun ", // 0x2a
        "Chi ", // 0x2b
        "Sang ", // 0x2c
        "Niao ", // 0x2d
        "Ying ", // 0x2e
        "Jie ", // 0x2f
        "Qian ", // 0x30
        "Huai ", // 0x31
        "Ku ", // 0x32
        "Lian ", // 0x33
        "Bao ", // 0x34
        "Li ", // 0x35
        "Zhe ", // 0x36
        "Shi ", // 0x37
        "Lu ", // 0x38
        "Yi ", // 0x39
        "Die ", // 0x3a
        "Xie ", // 0x3b
        "Xian ", // 0x3c
        "Wei ", // 0x3d
        "Biao ", // 0x3e
        "Cao ", // 0x3f
        "Ji ", // 0x40
        "Jiang ", // 0x41
        "Sen ", // 0x42
        "Bao ", // 0x43
        "Xiang ", // 0x44
        "Chihaya ", // 0x45
        "Pu ", // 0x46
        "Jian ", // 0x47
        "Zhuan ", // 0x48
        "Jian ", // 0x49
        "Zui ", // 0x4a
        "Ji ", // 0x4b
        "Dan ", // 0x4c
        "Za ", // 0x4d
        "Fan ", // 0x4e
        "Bo ", // 0x4f
        "Xiang ", // 0x50
        "Xin ", // 0x51
        "Bie ", // 0x52
        "Rao ", // 0x53
        "Man ", // 0x54
        "Lan ", // 0x55
        "Ao ", // 0x56
        "Duo ", // 0x57
        "Gui ", // 0x58
        "Cao ", // 0x59
        "Sui ", // 0x5a
        "Nong ", // 0x5b
        "Chan ", // 0x5c
        "Lian ", // 0x5d
        "Bi ", // 0x5e
        "Jin ", // 0x5f
        "Dang ", // 0x60
        "Shu ", // 0x61
        "Tan ", // 0x62
        "Bi ", // 0x63
        "Lan ", // 0x64
        "Pu ", // 0x65
        "Ru ", // 0x66
        "Zhi ", // 0x67
        "[?] ", // 0x68
        "Shu ", // 0x69
        "Wa ", // 0x6a
        "Shi ", // 0x6b
        "Bai ", // 0x6c
        "Xie ", // 0x6d
        "Bo ", // 0x6e
        "Chen ", // 0x6f
        "Lai ", // 0x70
        "Long ", // 0x71
        "Xi ", // 0x72
        "Xian ", // 0x73
        "Lan ", // 0x74
        "Zhe ", // 0x75
        "Dai ", // 0x76
        "Tasuki ", // 0x77
        "Zan ", // 0x78
        "Shi ", // 0x79
        "Jian ", // 0x7a
        "Pan ", // 0x7b
        "Yi ", // 0x7c
        "Ran ", // 0x7d
        "Ya ", // 0x7e
        "Xi ", // 0x7f
        "Xi ", // 0x80
        "Yao ", // 0x81
        "Feng ", // 0x82
        "Tan ", // 0x83
        "[?] ", // 0x84
        "Biao ", // 0x85
        "Fu ", // 0x86
        "Ba ", // 0x87
        "He ", // 0x88
        "Ji ", // 0x89
        "Ji ", // 0x8a
        "Jian ", // 0x8b
        "Guan ", // 0x8c
        "Bian ", // 0x8d
        "Yan ", // 0x8e
        "Gui ", // 0x8f
        "Jue ", // 0x90
        "Pian ", // 0x91
        "Mao ", // 0x92
        "Mi ", // 0x93
        "Mi ", // 0x94
        "Mie ", // 0x95
        "Shi ", // 0x96
        "Si ", // 0x97
        "Zhan ", // 0x98
        "Luo ", // 0x99
        "Jue ", // 0x9a
        "Mi ", // 0x9b
        "Tiao ", // 0x9c
        "Lian ", // 0x9d
        "Yao ", // 0x9e
        "Zhi ", // 0x9f
        "Jun ", // 0xa0
        "Xi ", // 0xa1
        "Shan ", // 0xa2
        "Wei ", // 0xa3
        "Xi ", // 0xa4
        "Tian ", // 0xa5
        "Yu ", // 0xa6
        "Lan ", // 0xa7
        "E ", // 0xa8
        "Du ", // 0xa9
        "Qin ", // 0xaa
        "Pang ", // 0xab
        "Ji ", // 0xac
        "Ming ", // 0xad
        "Ying ", // 0xae
        "Gou ", // 0xaf
        "Qu ", // 0xb0
        "Zhan ", // 0xb1
        "Jin ", // 0xb2
        "Guan ", // 0xb3
        "Deng ", // 0xb4
        "Jian ", // 0xb5
        "Luo ", // 0xb6
        "Qu ", // 0xb7
        "Jian ", // 0xb8
        "Wei ", // 0xb9
        "Jue ", // 0xba
        "Qu ", // 0xbb
        "Luo ", // 0xbc
        "Lan ", // 0xbd
        "Shen ", // 0xbe
        "Di ", // 0xbf
        "Guan ", // 0xc0
        "Jian ", // 0xc1
        "Guan ", // 0xc2
        "Yan ", // 0xc3
        "Gui ", // 0xc4
        "Mi ", // 0xc5
        "Shi ", // 0xc6
        "Zhan ", // 0xc7
        "Lan ", // 0xc8
        "Jue ", // 0xc9
        "Ji ", // 0xca
        "Xi ", // 0xcb
        "Di ", // 0xcc
        "Tian ", // 0xcd
        "Yu ", // 0xce
        "Gou ", // 0xcf
        "Jin ", // 0xd0
        "Qu ", // 0xd1
        "Jiao ", // 0xd2
        "Jiu ", // 0xd3
        "Jin ", // 0xd4
        "Cu ", // 0xd5
        "Jue ", // 0xd6
        "Zhi ", // 0xd7
        "Chao ", // 0xd8
        "Ji ", // 0xd9
        "Gu ", // 0xda
        "Dan ", // 0xdb
        "Zui ", // 0xdc
        "Di ", // 0xdd
        "Shang ", // 0xde
        "Hua ", // 0xdf
        "Quan ", // 0xe0
        "Ge ", // 0xe1
        "Chi ", // 0xe2
        "Jie ", // 0xe3
        "Gui ", // 0xe4
        "Gong ", // 0xe5
        "Hong ", // 0xe6
        "Jie ", // 0xe7
        "Hun ", // 0xe8
        "Qiu ", // 0xe9
        "Xing ", // 0xea
        "Su ", // 0xeb
        "Ni ", // 0xec
        "Ji ", // 0xed
        "Lu ", // 0xee
        "Zhi ", // 0xef
        "Zha ", // 0xf0
        "Bi ", // 0xf1
        "Xing ", // 0xf2
        "Hu ", // 0xf3
        "Shang ", // 0xf4
        "Gong ", // 0xf5
        "Zhi ", // 0xf6
        "Xue ", // 0xf7
        "Chu ", // 0xf8
        "Xi ", // 0xf9
        "Yi ", // 0xfa
        "Lu ", // 0xfb
        "Jue ", // 0xfc
        "Xi ", // 0xfd
        "Yan ", // 0xfe
        "Xi " // 0xff
    };
}
